
$(function(){
    // $('.btn').on('click',function(){
    //     document.getElementById('input_login').value = "";
    // });
    
    // $('.menu__btn').on('click',function(){
    //   $('.header__menu').slideToggle();
    // });
   // $('input, select').styler();
    $('.header__userbox-name').click(function(event){
        // if ($('.content').hasClass('dark__theme')){
        //     $('.content').removeClass('dark__theme');
        // }else {
        //     $('.content').addClass('dark__theme');
        // }

        if ($('body').hasClass('dark__theme')){
            $('body').removeClass('dark__theme');
        }else {
            $('body').addClass('dark__theme');
        }

      });
});